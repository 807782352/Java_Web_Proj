package priv.kyrie.item;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GoodsAddServlet
 */
@WebServlet("/add")
public class GoodsAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GoodsAddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		String id = request.getParameter("goodsId");
		String name = request.getParameter("goodsName");
		String type = request.getParameter("goodsType");
		double price = Float.parseFloat(request.getParameter("price"));
		String description = request.getParameter("description");
		Goods good = new Goods(id,name,type,price,description);
		
		ServletContext context = request.getServletContext();
		List goodList = (List) context.getAttribute("goods");
		goodList.add(good);
		request.setAttribute("goods", goodList);
		request.getRequestDispatcher("/goods.jsp").forward(request, response);
	}

}
